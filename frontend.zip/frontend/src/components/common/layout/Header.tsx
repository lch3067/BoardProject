import * as React from "react";

function Header() {
    return (
      <div id="header">
          <h2>Header 영역</h2>
      </div>
    );
}

export default Header;