import * as React from "react";
import './Body.css';

const Body = () => {
    return(
        <div id="body">
            <h2>Body.tsx 영역</h2>
            <h3>page 이름</h3>
        </div>
    );
}

export default Body;