function Menu2() {
    return(
        <h3>Menu2.tsx</h3>
    );
}

export default Menu2;