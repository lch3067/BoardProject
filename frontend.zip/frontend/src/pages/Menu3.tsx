function Menu3() {
    return(
        <h3>Menu3.tsx</h3>
    );
}

export default Menu3;