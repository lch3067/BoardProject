function Menu1() {
    return(
        <h3>Menu1.tsx</h3>
    );
}

export default Menu1;