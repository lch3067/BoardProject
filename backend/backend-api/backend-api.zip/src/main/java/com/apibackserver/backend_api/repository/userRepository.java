package com.apibackserver.backend_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.apibackserver.backend_api.model.User;

@Repository
public interface userRepository extends JpaRepository<User, Long> {

}
