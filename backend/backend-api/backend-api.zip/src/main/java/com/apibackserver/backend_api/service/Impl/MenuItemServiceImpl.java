package com.apibackserver.backend_api.service.Impl;

import com.apibackserver.backend_api.dto.MenuItemDto;
import com.apibackserver.backend_api.model.MenuItem;
import com.apibackserver.backend_api.repository.MenuItemRepository;
import com.apibackserver.backend_api.service.MenuItemService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MenuItemServiceImpl implements MenuItemService {

    private final MenuItemRepository menuItemRepository;

    public MenuItemServiceImpl(MenuItemRepository menuItemRepository) {
        this.menuItemRepository = menuItemRepository;
    }

    @Override
    public List<MenuItemDto> getMenuTree() {
        // 최상위 메뉴 가져오기
        List<MenuItem> rootMenus = menuItemRepository.findBySuperMenuId("ROOT");

        // JSON 트리 구조로 변환
        return rootMenus.stream()
                .map(this::buildMenuTree)
                .collect(Collectors.toList());
    }

    private MenuItemDto buildMenuTree(MenuItem menu) {
        MenuItemDto dto = new MenuItemDto();
        dto.setMenuId(menu.getMenuId());
        dto.setSuperMenuId(menu.getSuperMenuId()); // 부모 ID 설정
        dto.setMenuUrl(menu.getMenuUrl());
        dto.setMenuDesc(menu.getMenuDesc());

         // 자식 메뉴 가져오기
         List<MenuItemDto> children = menu.getChildren().stream()
                    .map(this::buildMenuTree)
                    .collect(Collectors.toList());

        dto.setChildren(children);

        return dto;
    }
}