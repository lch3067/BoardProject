

package com.apibackserver.backend_api.service;

import com.apibackserver.backend_api.model.User;

import com.apibackserver.backend_api.service.UserService;

import java.util.List;



public interface  UserService  {
    List<User> getAllUsers();    // 모든 유저 가져오기
    User getUserById(Long id);  // 특정 유저 가져오기
}
