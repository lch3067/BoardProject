package com.apibackserver.backend_api.repository;

import com.apibackserver.backend_api.model.MenuItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, String> {
    List<MenuItem> findBySuperMenuId(String superMenuId);
}
