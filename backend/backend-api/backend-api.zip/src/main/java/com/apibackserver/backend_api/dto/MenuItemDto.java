package com.apibackserver.backend_api.dto;

import java.util.ArrayList;
import java.util.List;

public class MenuItemDto {

    private String menuId;
    private String superMenuId; // 부모 ID
    private String menuUrl;
    private String menuDesc;
    private List<MenuItemDto> children = new ArrayList<>();

    // Getter and Setter for menuId
    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    // Getter and Setter for superMenuId
    public String getSuperMenuId() {
        return superMenuId;
    }

    public void setSuperMenuId(String superMenuId) {
        this.superMenuId = superMenuId;
    }

    // Getter and Setter for menuUrl
    public String getMenuUrl() {
        return menuUrl;
    }

    public void setMenuUrl(String menuUrl) {
        this.menuUrl = menuUrl;
    }

    // Getter and Setter for menuDesc
    public String getMenuDesc() {
        return menuDesc;
    }

    public void setMenuDesc(String menuDesc) {
        this.menuDesc = menuDesc;
    }

    // Getter and Setter for children
    public List<MenuItemDto> getChildren() {
        return children;
    }

    public void setChildren(List<MenuItemDto> children) {
        this.children = children;
    }
}
