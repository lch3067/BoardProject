package com.apibackserver.backend_api.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "MENU_MST")
public class MenuItem {

    @Id
    @Column(name = "MENU_ID")
    private String menuId;

    @Column(name = "SUPER_MENU_ID")
    private String superMenuId;

    @Column(name = "MENU_URL")
    private String menuUrl;

    @Column(name = "MENU_DESC")
    private String menuDesc;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<MenuItem> children;

    @ManyToOne
    @JoinColumn(name = "SUPER_MENU_ID", insertable = false, updatable = false)
    private MenuItem parent;

    // Getters and Setters
    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getSuperMenuId() {
        return superMenuId;
    }

    public void setSuperMenuId(String superMenuId) {
        this.superMenuId = superMenuId;
    }

    public String getMenuUrl() {
        return menuUrl;
    }

    public void setMenuUrl(String menuUrl) {
        this.menuUrl = menuUrl;
    }

    public String getMenuDesc() {
        return menuDesc;
    }

    public void setMenuDesc(String menuDesc) {
        this.menuDesc = menuDesc;
    }

    public List<MenuItem> getChildren() {
        return children;
    }

    public void setChildren(List<MenuItem> children) {
        this.children = children;
    }

    public MenuItem getParent() {
        return parent;
    }

    public void setParent(MenuItem parent) {
        this.parent = parent;
    }
}