package com.apibackserver.backend_api.service.Impl;

import com.apibackserver.backend_api.model.User;
import com.apibackserver.backend_api.repository.userRepository;
import com.apibackserver.backend_api.service.UserService;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import com.apibackserver.backend_api.service.Impl.UserServiceImpl;

@Service
public class UserServiceImpl implements UserService{
  
     private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    private final userRepository repository;

    public UserServiceImpl(userRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<User> getAllUsers() {
        List<User> users = repository.findAll();
        logger.info("Fetched Users: {}", users);
        return users;
    }

    @Override
    public User getUserById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
}
